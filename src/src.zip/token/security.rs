use crate::AppConfig;
use crate::AppState;
use crate::build::build_info::get;
use crate::config::config::RegexCond;
use crate::config::config::RouteRule;
use crate::network::canonical_url::canonicalize_path_for_match;
use crate::revoke::load::is_token_revoked;
use crate::token::crypto::{calcul_factorhash, decrypt, derive_key_from_secret};
use actix_web::HttpRequest;
use actix_web::http::StatusCode;
use actix_web::http::header::HeaderMap;
use actix_web::web;
use blake3;
use chrono::{DateTime, Duration, TimeZone, Timelike, Utc};
use chrono_tz::Tz;
use regex::Regex;
use serde_json::Value as JsonValue;
use std::collections::HashMap;
use std::sync::OnceLock;
use subtle::ConstantTimeEq;
use tracing::{error, info, warn};

pub fn get_build_time() -> u64 {
    let get_build = get();
    let data = get_build.build_time;
    data
}

pub fn get_build_rand() -> u64 {
    let get_build = get();
    let data = get_build.build_rand;
    data
}

pub fn get_build_seed2() -> u64 {
    let get_build = get();
    let data = get_build.build_seed2;
    data
}

pub fn get_build_epochdate() -> i64 {
    let get_build = get();
    let data = get_build.build_epoch;
    data
}

pub fn get_build_datetime() -> chrono::DateTime<chrono::Utc> {
    let seconds = get_build_epochdate();
    let naive = Utc.timestamp_opt(seconds, 0).unwrap();
    naive
}

pub fn get_build_hk() -> String {
    let get_build = get();
    let data = get_build.build_hk;
    data
}

static DERIVED_KEY: OnceLock<[u8; 32]> = OnceLock::new();

#[allow(dead_code)]
pub fn format_long_date(seconds: u128) -> String {
    let seconds_per_year = 31_557_600u128;
    let year = seconds / seconds_per_year;
    let remaining = seconds % seconds_per_year;

    let _days = remaining / 86400;
    let hours = (remaining % 86400) / 3600;
    let minutes = (remaining % 3600) / 60;
    let seconds = remaining % 60;

    format!(
        "+{:0>8}-01-01T{:02}:{:02}:{:02}Z",
        year, hours, minutes, seconds
    )
}

pub fn init_derived_key(secret: &str) {
    let key = derive_key_from_secret(secret);
    DERIVED_KEY.set(key).expect("Key already initialized");
}

pub fn check_date_token(
    time_str: &str,
    username: &str,
    ip: &str,
    timezone: &str,
) -> Result<u64, ()> {
    let tz: Tz = timezone.parse().map_err(|_| {
        warn!("[{}] invalid timezone '{}'", ip, timezone);
        ()
    })?;

    let expire_time = time_str
        .parse::<DateTime<Utc>>()
        .or_else(|_| {
            time_str
                .parse::<i64>()
                .map(|ts| Utc.timestamp_opt(ts, 0).single().unwrap())
        })
        .map_err(|_| {
            warn!("[{}] failed to parse expiration time: {}", ip, time_str);
            ()
        })?;

    let expire_local = expire_time.with_timezone(&tz);
    let now_local = Utc::now().with_timezone(&tz);

    if now_local.timestamp() >= expire_local.timestamp() {
        warn!("[{}] token is expired for user {}", ip, username);
        return Err(());
    }

    let diff = expire_local.timestamp() - now_local.timestamp();
    diff.try_into().map_err(|_| ())
}

pub fn generate_secret(secret: &str, token_expiry_seconds: &i64) -> String {
    let base = get_build_datetime();

    let next_reset_time = match *token_expiry_seconds {
        0..=86_400 => base + Duration::seconds(*token_expiry_seconds),

        86_401..=2_419_200 => {
            let weeks = (*token_expiry_seconds as f64 / (7.0 * 86400.0)).ceil() as i64;
            base + Duration::days(weeks * 7)
        }

        2_419_201..=31_104_000 => {
            let months = (*token_expiry_seconds as f64 / (30.0 * 86400.0)).ceil() as u32;

            let mut year = 0;
            let mut month = 1 + months;

            while month > 12 {
                month -= 12;
                year += 1;
            }

            let (next_year, next_month) = if month == 12 {
                (year + 1, 1)
            } else {
                (year, month + 1)
            };

            let first_of_next_month = Utc
                .with_ymd_and_hms(next_year as i32, next_month, 1, 0, 0, 0)
                .unwrap();

            let last_day = first_of_next_month - Duration::days(1);
            last_day
                .with_hour(23)
                .unwrap()
                .with_minute(59)
                .unwrap()
                .with_second(59)
                .unwrap()
        }

        31_104_001..=157_680_000 => {
            let years = (*token_expiry_seconds as f64 / (365.0 * 86400.0)).ceil() as i32;
            Utc.with_ymd_and_hms(0 + years, 12, 31, 23, 59, 59).unwrap()
        }

        _ => base + Duration::seconds(86_400),
    };

    let now = Utc::now();
    let _remaining_seconds = (next_reset_time - now).num_seconds();

    format!("{}:{}", secret, next_reset_time.timestamp())
}

pub fn generate_token(
    username: &str,
    config: &AppConfig,
    time_expire: &str,
    token_id: &str,
) -> String {
    let values_map = HashMap::from([
        ("username", username.to_string()),
        (
            "secret_with_timestamp",
            generate_secret(&config.secret, &config.token_expiry_seconds),
        ),
        ("build_time", get_build_time().to_string()),
        ("time_expire", time_expire.to_string()),
        ("build_rand", get_build_rand().to_string()),
        ("token_id", token_id.to_string()),
        ("hk", get_build_hk()),
    ]);

    let shuffled: Vec<String> = get()
        .shuffled_order_list()
        .iter()
        .map(|k| values_map[k.as_str()].clone())
        .collect();

    let shuffle_data = shuffled.join(":");
    blake3::hash(shuffle_data.as_bytes()).to_hex().to_string()
}

pub async fn validate_token(
    token: &str,
    data_app: &web::Data<AppState>,
    config: &AppConfig,
    ip: &str,
) -> Result<(String, String, u64), String> {
    let key = derive_key_from_secret(&config.secret);

    let decrypt_token = decrypt(token, &key).map_err(|_| "Invalid token format")?;

    let data: [&str; 4] = decrypt_token
        .splitn(4, '|')
        .collect::<Vec<&str>>()
        .try_into()
        .map_err(|_| "Invalid token format")?;

    let token_hash_decrypt = data[0];

    let index_user = data[2].parse::<usize>().map_err(|_| "Index invalide")?;
    let user = config.user_by_index(index_user).ok_or("User not found")?;

    let time_expire = check_date_token(data[1], &user.username, ip, &config.timezone)
        .map_err(|_| "Your token is expired")?;

    if (time_expire > (config.token_expiry_seconds as i64).try_into().unwrap())
        .try_into()
        .unwrap()
    {
        error!(
            "[{}] username {} try to access token limit config {} value request {}",
            ip, user.username, config.token_expiry_seconds, time_expire
        );
        return Err("Bad time token".to_string());
    }

    let token_generated = generate_token(&user.username, &config, data[1], data[3]);

    // mode fast token is more speed but less secure
    // and fast is false token is more secure but it's slower
    let token_hash = if config.fast {
        token_generated.clone()
    } else {
        calcul_factorhash(token_generated.clone())
    };

    // SECURITY: constant-time comparison for both branches — this token
    // hash is a secret being verified, and a plain `!=` on strings leaks
    // timing information about how many leading bytes matched.
    if config.fast {
        if !bool::from(
            token_generated
                .clone()
                .as_bytes()
                .ct_eq(token_hash_decrypt.as_bytes()),
        ) {
            warn!("[{}] Invalid token", ip);
            return Err("no valid token".to_string());
        }
    } else {
        let computed = blake3::hash(token_hash.as_bytes()).to_hex().to_string();
        if !bool::from(computed.as_bytes().ct_eq(token_hash_decrypt.as_bytes())) {
            warn!("[{}] Invalid token", ip);
            return Err("no valid token".to_string());
        }
    }

    if is_token_revoked(data[3], &data_app.revoked_tokens) {
        warn!(
            "[{}] token_id {} is revoked from user {}",
            ip, data[3], user.username
        );
        return Err("revoked token".to_string());
    }

    if config.stats {
        let count =
            data_app
                .counter
                .record_and_get(&user.username, data[3], &time_expire.to_string());

        info!(
            "[{}] user {} is logged token expire in {} seconds [token used: {}]",
            ip, user.username, time_expire, count
        );
    } else {
        info!(
            "[{}] user {} is logged token expire in {} seconds",
            ip, user.username, time_expire
        );
    }

    Ok((user.username.to_string(), data[3].to_string(), time_expire))
}

pub fn extract_token_user(token: &str, config: &AppConfig, ip: String) -> Result<String, String> {
    let key = derive_key_from_secret(&config.secret);

    let decrypt_token = match decrypt(token, &key) {
        Ok(val) => val,
        Err(_) => {
            warn!("[{}] Failed to decrypt token (invalid format)", ip);
            return Err("Invalid token format".into());
        }
    };

    let data: Vec<&str> = decrypt_token.split('|').collect();

    if data.len() < 3 {
        warn!("[{}] Token structure is invalid (not enough segments)", ip);
        return Err("Invalid token content".into());
    }

    let index_user: usize = match data[2].parse() {
        Ok(i) => i,
        Err(_) => {
            warn!("[{}] Failed to parse user index from token", ip);
            return Err("Invalid user index".into());
        }
    };

    if let Some(user) = config.user_by_index(index_user) {
        Ok(user.username.clone())
    } else {
        warn!("[{}] User index out of bounds: {}", ip, index_user);
        Err("User not found".into())
    }
}

pub fn all_values_match<'a, I>(vals: I, re: &Regex) -> bool
where
    I: IntoIterator<Item = &'a str>,
{
    vals.into_iter().all(|v| re.is_match(v))
}

pub fn parse_query_map(q: &str) -> HashMap<String, Vec<String>> {
    let mut map = HashMap::<String, Vec<String>>::new();
    for pair in q.split('&').filter(|s| !s.is_empty()) {
        let mut it = pair.splitn(2, '=');
        let k = it.next().unwrap_or("").to_string();
        let v = it.next().unwrap_or("").to_string();
        map.entry(k).or_default().push(v);
    }
    map
}

pub fn apply_filters_regex_allow_only(
    rule: &RouteRule,
    req: &HttpRequest,
    body: &[u8],
) -> Option<StatusCode> {
    let compiled = match &rule.filters_compiled {
        Some(c) => c,
        None => return None,
    };

    let method = req.method();
    let path_canon = canonicalize_path_for_match(req.uri().path());
    let query = parse_query_map(req.uri().query().unwrap_or("")); // HashMap<String, Vec<String>>

    let mut need_utf8 = false;
    let mut need_json = false;
    for c in &compiled.allow {
        match c {
            RegexCond::BodyRaw { .. } => need_utf8 = true,
            RegexCond::BodyJson { .. } => need_json = true,
            _ => {}
        }
    }

    let ct = req
        .headers()
        .get(actix_web::http::header::CONTENT_TYPE)
        .and_then(|v| v.to_str().ok())
        .unwrap_or("")
        .to_ascii_lowercase();

    let body_utf8 = if need_utf8 {
        std::str::from_utf8(body).ok()
    } else {
        None
    };

    let body_json = if need_json && ct.contains("application/json") {
        serde_json::from_slice::<JsonValue>(body).ok()
    } else {
        None
    };

    if compiled.allow.is_empty() {
        return if compiled.default_allow {
            None
        } else {
            Some(StatusCode::FORBIDDEN)
        };
    }

    let ok = compiled.allow.iter().all(|cond| {
        cond_matches_strict(
            cond,
            method,
            &path_canon,
            req.headers().clone(),
            &query,
            body_utf8,
            body_json.as_ref(),
            &ct,
        )
    });

    if ok {
        None
    } else {
        Some(StatusCode::FORBIDDEN)
    }
}

pub fn cond_matches_strict(
    cond: &RegexCond,
    method: &actix_web::http::Method,
    path: &str,
    headers: HeaderMap,
    query: &std::collections::HashMap<String, Vec<String>>,
    body_utf8: Option<&str>,
    body_json: Option<&JsonValue>,
    content_type_lower: &str,
) -> bool {
    match cond {
        RegexCond::Method { re } => re.is_match(method.as_str()),
        RegexCond::Path { re } => re.is_match(path),

        RegexCond::Header { name_re, re } => {
            let mut matched_any_name = false;
            let mut values_for_matched_names: Vec<String> = Vec::new();

            for (k, v) in headers.iter() {
                let name = k.as_str();
                if name_re.is_match(name) {
                    matched_any_name = true;
                    if let Ok(val) = v.to_str() {
                        values_for_matched_names.push(val.to_string());
                    } else {
                        return false;
                    }
                }
            }

            if !matched_any_name {
                return false;
            }

            all_values_match(values_for_matched_names.iter().map(|s| s.as_str()), re)
        }

        RegexCond::Query { name_re, re } => {
            let mut matched_any_name = false;

            for (k, vals) in query {
                if name_re.is_match(k) {
                    matched_any_name = true;

                    if !all_values_match(vals.iter().map(|s| s.as_str()), re) {
                        return false;
                    }
                }
            }

            matched_any_name
        }

        RegexCond::BodyRaw { re } => match body_utf8 {
            Some(s) => re.is_match(s),
            None => false,
        },

        RegexCond::BodyJson { key, re } => {
            if !content_type_lower.contains("application/json") {
                return false;
            }
            let Some(j) = body_json else {
                return false;
            };

            match j.get(key) {
                Some(JsonValue::String(s)) => re.is_match(s),
                Some(JsonValue::Number(n)) => re.is_match(&n.to_string()),
                Some(JsonValue::Bool(b)) => re.is_match(if *b { "true" } else { "false" }),
                Some(other) => re.is_match(&other.to_string()),
                None => false,
            }
        }
    }
}
