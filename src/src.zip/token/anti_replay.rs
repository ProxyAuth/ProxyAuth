//! Request-signing anti-replay plugin — activated by `plugin_anti_replay:
//! true` in `config.json` (see `AppConfig::plugin_anti_replay`,
//! `RouteRule::need_anti_replay`).
//!
//! A signing client (typically the ProxyAuth browser extension) attaches
//! four headers to each request it makes:
//!
//! ```text
//! X-User:      <username>     — which ProxyAuth account signed this
//! X-Timestamp: <unix ms>      — when the request was signed
//! X-Nonce:     <base64 bytes> — random, unique per request
//! X-Signature: <base64 HMAC>  — HMAC-SHA256 over a canonical string
//! ```
//!
//! The canonical string being signed is:
//!
//! ```text
//! METHOD|scheme|host|port|path|query|timestamp|nonce|username|bodyHash
//! ```
//!
//! — `query` includes its leading `?` when present (empty string
//! otherwise), and `bodyHash` is the base64 SHA-256 of the raw request
//! body (empty string for a bodyless request). This has to match the
//! signing client byte-for-byte; see the browser extension's
//! `background.js` (`buildSignatureHeaders`) for the reference
//! implementation this mirrors.
//!
//! ## The signing secret lives on the account
//!
//! Unlike a separate device-registration scheme, there's nothing to
//! provision by hand: every `User` account gets its own HMAC secret
//! (`User.anti_replay_secret`), generated automatically — the first
//! time an account is seen with `plugin_anti_replay: true` and no
//! secret on file yet, in whichever backend stores that account
//! (`config.json`, LMDB fallback cache, or the `databases` table — see
//! `ensure_secret_for_user`/`ensure_secrets_for_db_users`) — and mailed
//! to the account's on-file address exactly once, via a template
//! containing `{{ secret_anti_replay }}` (see `smtp::smtp::SmtpClient`,
//! `smtp::template`). The user pastes that secret into the signing
//! extension against their own username; nothing else to register.
//!
//! ## Two independent in-memory stores, fed from that one source of truth
//!
//! - **Key registry** (`KEY_REGISTRY`): `username -> decrypted HMAC
//!   secret`, rebuilt from `AppConfig::combined_users()` — see
//!   `reload_keys`. Since `combined_users()` already merges file-based
//!   and database-backed accounts and is kept fresh by the existing
//!   user-refresh cycle, this is a cheap, purely in-memory pass: no
//!   separate loading/caching logic of its own. Each secret is
//!   decrypted once per reload with a key derived from
//!   `AppConfig.secret` (`token::crypto::derive_key_from_secret`); the
//!   raw secret then lives in RAM for as long as the process runs, the
//!   same tradeoff the signing extension itself makes.
//!
//! - **Nonce store** (`NONCE_STORE` + a dedicated LMDB environment):
//!   `"username:nonce" -> expiry (unix secs)`, used purely for replay
//!   detection within the timestamp tolerance window
//!   (`AppConfig.anti_replay_window_secs`). Mirrored to LMDB so a
//!   restart doesn't reset the replay window to empty — same idea as
//!   `revoke::db`'s token-revocation store, but self-contained (no
//!   Redis cross-instance sync): a nonce only needs to be remembered for
//!   the few seconds/minutes its timestamp stays valid anyway, so the
//!   window for a cross-instance replay in a multi-instance deployment
//!   without shared state is bounded by the same number — worth knowing
//!   about, not worth the complexity of wiring in Redis here too.

use crate::config::config::{AppConfig, DatabaseConfig, User};
use crate::token::crypto::{decrypt, derive_key_from_secret, encrypt};
use actix_web::HttpRequest;
use actix_web::http::header::HOST;
use base64::{Engine as _, engine::general_purpose::STANDARD as B64};
use bytes::Bytes;
use dashmap::DashMap;
use dashmap::mapref::entry::Entry;
use lmdb::{Cursor, Environment, Transaction, WriteFlags};
use once_cell::sync::{Lazy, OnceCell};
use rand::RngCore;
use rand::rngs::OsRng;
use sha2::{Digest, Sha256};
use std::collections::HashSet;
use std::path::{Path, PathBuf};
use std::sync::Mutex;
use std::time::{SystemTime, UNIX_EPOCH};
use subtle::ConstantTimeEq;
use tracing::{debug, error, info, warn};

/// Why a request was rejected — kept specific rather than a bare `bool`
/// so callers can log/respond with something more useful than "no".
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum AntiReplayError {
    /// One or more of X-User/X-Timestamp/X-Nonce/X-Signature is
    /// missing, empty, or (for X-Signature) not valid base64.
    MissingOrMalformedHeaders,
    /// `X-User` doesn't match any currently-registered, non-revoked
    /// signing key.
    UnknownClient,
    /// `X-Timestamp` is further from this server's clock than
    /// `anti_replay_window_secs` allows, in either direction.
    ClockSkew,
    /// The HMAC didn't verify against the reconstructed canonical
    /// string for this exact request (method/URL/body/nonce/timestamp).
    InvalidSignature,
    /// This exact (uid, nonce) pair was already consumed — either a
    /// genuine replay or (far more likely in practice) the same
    /// request retried by a client/proxy without regenerating a fresh
    /// nonce.
    Replayed,
}

impl AntiReplayError {
    /// Stable, machine-readable reason string — used both in the log
    /// line and in the JSON body returned to the caller, so a signing
    /// client can tell *why* a request was rejected without parsing
    /// prose.
    pub fn as_str(&self) -> &'static str {
        match self {
            Self::MissingOrMalformedHeaders => "missing_or_malformed_signature_headers",
            Self::UnknownClient => "unknown_signing_client",
            Self::ClockSkew => "timestamp_out_of_window",
            Self::InvalidSignature => "invalid_signature",
            Self::Replayed => "replayed_request",
        }
    }
}

impl std::fmt::Display for AntiReplayError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(self.as_str())
    }
}

// ─────────────────────────────────────────────────────────────────────────
// Key registry: username -> decrypted HMAC secret
// ─────────────────────────────────────────────────────────────────────────

pub static KEY_REGISTRY: Lazy<DashMap<String, String>> = Lazy::new(DashMap::new);

/// Rebuilds the key registry from `AppConfig::combined_users()` — a
/// cheap, purely in-memory pass, since `combined_users()` is already
/// kept fresh by the existing user-refresh cycle (file users once at
/// startup, database users on every `refresh_db_users`/
/// `refresh_db_users_incremental` tick). Safe to call as often as
/// convenient; never panics.
///
/// A user with no `anti_replay_secret` yet is simply absent from the
/// registry (their signed requests are rejected as `UnknownClient`
/// until one is generated — see `ensure_secret_for_user`). A user whose
/// secret fails to decrypt (wrong `AppConfig.secret`, or a
/// corrupted/hand-edited value) is logged and skipped rather than
/// treated as a hard error.
pub fn reload_keys(config: &AppConfig) {
    if !config.plugin_anti_replay {
        return;
    }

    let users = config.combined_users();
    let server_key = derive_key_from_secret(&config.secret);
    let mut seen: HashSet<String> = HashSet::with_capacity(users.len());

    for user in &users {
        let Some(enc) = &user.anti_replay_secret else {
            continue;
        };
        match decrypt(enc, &server_key) {
            Ok(plain) => {
                seen.insert(user.username.clone());
                KEY_REGISTRY.insert(user.username.clone(), plain);
            }
            Err(_) => {
                error!(
                    "[anti-replay] failed to decrypt the signing secret for user={} — skipping (wrong AppConfig.secret, or a corrupted/hand-edited value?)",
                    user.username
                );
            }
        }
    }

    KEY_REGISTRY.retain(|username, _| seen.contains(username));
    debug!(
        "[anti-replay] key registry reloaded: {} active account(s)",
        KEY_REGISTRY.len()
    );
}

// ─────────────────────────────────────────────────────────────────────────
// Secret generation + the welcome-email queue
// ─────────────────────────────────────────────────────────────────────────

/// One secret that was just generated for an account and is waiting to
/// be emailed out. Sync code paths (`config::load_config`,
/// `AppConfig::refresh_db_users*`, the `db-add-user` CLI command) push
/// onto `PENDING_WELCOME_EMAILS` — none of them are in a position to
/// `.await` an SMTP send directly — and an async task in `main`
/// (`drain_pending_welcome_emails`) does the actual sending.
///
/// The plaintext secret only ever exists transiently, in this queue,
/// between being generated and being sent — it's never written to
/// disk/DB in the clear. If the email genuinely can't be delivered
/// (SMTP misconfigured, address bounces, etc.), it's gone: the fix is
/// to clear that account's `anti_replay_secret` (JSON: edit
/// config.json; database: `UPDATE users SET anti_replay_secret = NULL
/// WHERE username = ...`) so a fresh one gets generated and mailed on
/// the next load/refresh, not to try to recover the lost plaintext.
pub struct PendingWelcomeEmail {
    pub username: String,
    pub email: String,
    pub secret_plain: String,
}

pub static PENDING_WELCOME_EMAILS: Lazy<Mutex<Vec<PendingWelcomeEmail>>> =
    Lazy::new(|| Mutex::new(Vec::new()));

/// Generates a fresh random signing secret (32 bytes, hex-encoded —
/// deliberately not base64: no `+`/`/`/`=` to trip up a naive
/// copy-paste into the extension's plain-text secret field) and
/// encrypts it for storage. Returns `(plaintext, ciphertext)` — the
/// plaintext is for `queue_welcome_email` only, never persisted.
pub fn generate_and_encrypt_secret(server_secret: &str) -> (String, String) {
    let mut raw = [0u8; 32];
    OsRng.fill_bytes(&mut raw);
    let plain = raw.iter().map(|b| format!("{b:02x}")).collect::<String>();

    let key = derive_key_from_secret(server_secret);
    let encrypted = encrypt(&plain, &key);

    (plain, encrypted)
}

/// Queues a welcome email for a freshly generated secret, if the
/// account has an email on file — logs a clear warning instead if it
/// doesn't (the secret is already generated and stored at this point;
/// with no address to send it to, an admin has to communicate it out
/// of band, or add an email and let it be re-sent on the next
/// load/refresh — see `PendingWelcomeEmail`).
pub fn queue_welcome_email(username: String, email: Option<String>, secret_plain: String) {
    match email {
        Some(email) => {
            info!(
                "[anti-replay] generated a new signing secret for user={username}; queued for email delivery"
            );
            if let Ok(mut q) = PENDING_WELCOME_EMAILS.lock() {
                q.push(PendingWelcomeEmail {
                    username,
                    email,
                    secret_plain,
                });
            } else {
                error!(
                    "[anti-replay] welcome-email queue lock is poisoned — dropping the notification for user={username}"
                );
            }
        }
        None => {
            warn!(
                "[anti-replay] generated a new signing secret for user={username}, but this account has no email on file — it cannot be delivered automatically. Add one to 'email' in config.json (or the database) and clear anti_replay_secret to have it regenerated and mailed."
            );
        }
    }
}

/// Database-mode counterpart of the per-user loop in
/// `config::load_config` (JSON mode): ensures every user in `users`
/// that's missing a secret gets one generated, persisted to the
/// database, and queued for email — mutating `users` in place so the
/// caller's subsequent `apply_upserts` picks up the encrypted value.
///
/// If persisting to the database fails (connection issue, etc.), that
/// user is simply left without a secret and retried on the next
/// refresh tick — never left half-applied (in memory but not in the
/// database), which would desync `KEY_REGISTRY` from what a second
/// instance or a restart would see.
pub fn ensure_secrets_for_db_users(
    server_secret: &str,
    users: &mut [User],
    db_cfg: &DatabaseConfig,
) {
    for user in users.iter_mut() {
        if user.anti_replay_secret.is_some() {
            continue;
        }

        let (plain, encrypted) = generate_and_encrypt_secret(server_secret);

        if let Err(e) =
            crate::databases::db::set_anti_replay_secret(db_cfg, &user.username, &encrypted)
        {
            error!(
                "[anti-replay] failed to persist a new signing secret for user={}: {e}",
                user.username
            );
            continue;
        }

        user.anti_replay_secret = Some(encrypted);

        let email = crate::token::reset_password::find_user_email(
            std::slice::from_ref(&*user),
            &user.username,
        );
        queue_welcome_email(user.username.clone(), email, plain);
    }
}

// ─────────────────────────────────────────────────────────────────────────
// Nonce store — replay detection, backed by a dedicated LMDB environment
// ─────────────────────────────────────────────────────────────────────────

pub static NONCE_STORE: Lazy<DashMap<String, u64>> = Lazy::new(DashMap::new);
static NONCE_LMDB_ENV: OnceCell<Environment> = OnceCell::new();
static NONCE_LMDB_MUTEX: Mutex<()> = Mutex::new(());
const NONCE_DB_NAME: &str = "antireplay_nonces";

fn nonce_lmdb_path() -> PathBuf {
    PathBuf::from(
        std::env::var("PROXYAUTH_ANTIREPLAY_LMDB_PATH")
            .unwrap_or_else(|_| "/opt/proxyauth/db/antireplay/".to_string()),
    )
}

/// Deliberately its own LMDB environment/directory — same reasoning as
/// `databases::cache`: environments aren't meant to be reopened
/// concurrently by unrelated code paths, so keeping this one
/// independent of `revoke::db`'s and `databases::cache`'s avoids an
/// initialization-order dependency between all three.
fn nonce_env() -> Result<&'static Environment, String> {
    if let Some(env) = NONCE_LMDB_ENV.get() {
        return Ok(env);
    }

    let path = nonce_lmdb_path();
    std::fs::create_dir_all(&path).map_err(|e| {
        format!(
            "Failed to create anti-replay LMDB dir {}: {e}",
            path.display()
        )
    })?;

    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        let _ = std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o700));
    }

    let env = Environment::new()
        .set_max_dbs(1)
        .open(Path::new(&path))
        .map_err(|e| format!("Failed to open anti-replay LMDB at {}: {e}", path.display()))?;

    env.create_db(Some(NONCE_DB_NAME), lmdb::DatabaseFlags::empty())
        .map_err(|e| format!("Failed to create/open anti-replay LMDB nonce db: {e}"))?;

    let _ = NONCE_LMDB_ENV.set(env);
    NONCE_LMDB_ENV
        .get()
        .ok_or_else(|| "Anti-replay LMDB environment failed to initialize".to_string())
}

fn lmdb_put_nonce(key: &str, expiry_epoch_secs: u64) {
    let _guard = match NONCE_LMDB_MUTEX.lock() {
        Ok(g) => g,
        Err(poisoned) => poisoned.into_inner(),
    };
    let Ok(env) = nonce_env() else { return };
    let Ok(db) = env.open_db(Some(NONCE_DB_NAME)) else {
        return;
    };
    let Ok(mut txn) = env.begin_rw_txn() else {
        return;
    };
    let key_bytes: &[u8] = key.as_bytes();
    let value_bytes: &[u8] = &expiry_epoch_secs.to_be_bytes();
    let _ = txn.put::<&[u8], &[u8]>(db, &key_bytes, &value_bytes, WriteFlags::empty());
    let _ = txn.commit();
}

fn lmdb_delete_nonce(key: &str) {
    let _guard = match NONCE_LMDB_MUTEX.lock() {
        Ok(g) => g,
        Err(poisoned) => poisoned.into_inner(),
    };
    let Ok(env) = nonce_env() else { return };
    let Ok(db) = env.open_db(Some(NONCE_DB_NAME)) else {
        return;
    };
    let Ok(mut txn) = env.begin_rw_txn() else {
        return;
    };
    let key_bytes: &[u8] = key.as_bytes();
    let _ = txn.del::<&[u8]>(db, &key_bytes, None);
    let _ = txn.commit();
}

/// Loads every nonce still on file into `NONCE_STORE` — called once at
/// startup so a process restart doesn't momentarily forget nonces that
/// are still inside their replay window (expired ones are dropped here
/// rather than carried forward).
pub fn load_nonces_from_lmdb() {
    let now = now_epoch_secs();

    let _guard = match NONCE_LMDB_MUTEX.lock() {
        Ok(g) => g,
        Err(poisoned) => poisoned.into_inner(),
    };
    let Ok(env) = nonce_env() else { return };
    let Ok(db) = env.open_db(Some(NONCE_DB_NAME)) else {
        return;
    };
    let Ok(txn) = env.begin_ro_txn() else { return };
    let Ok(mut cursor) = txn.open_ro_cursor(db) else {
        return;
    };

    let mut loaded = 0usize;
    for result in cursor.iter() {
        let Ok((key, value)) = result else { continue };
        let Ok(key_str) = std::str::from_utf8(key) else {
            continue;
        };
        if value.len() != 8 {
            continue;
        }
        let expiry = u64::from_be_bytes(value.try_into().expect("checked len == 8"));
        if expiry <= now {
            continue; // already stale — no point carrying it into RAM
        }
        NONCE_STORE.insert(key_str.to_string(), expiry);
        loaded += 1;
    }
    info!("[anti-replay] loaded {loaded} still-valid nonce(s) from local store at startup");
}

/// Drops expired entries from both `NONCE_STORE` and the LMDB mirror.
/// Cheap to call on a slow interval (e.g. every `anti_replay_window_secs`)
/// — the store only ever grows between calls, by at most one entry per
/// signed request.
pub fn purge_expired_nonces() {
    let now = now_epoch_secs();

    // Collect first, delete from LMDB after `retain` has released
    // DashMap's internal shard locks — calling into a different lock
    // (the LMDB mutex, via `lmdb_delete_nonce`) while still holding
    // those would risk a lock-ordering inversion against
    // `load_nonces_from_lmdb` (which does the reverse: holds the LMDB
    // mutex, then touches `NONCE_STORE`).
    let mut removed_keys: Vec<String> = Vec::new();
    NONCE_STORE.retain(|key, expiry| {
        let keep = *expiry > now;
        if !keep {
            removed_keys.push(key.clone());
        }
        keep
    });

    for key in &removed_keys {
        lmdb_delete_nonce(key);
    }

    if !removed_keys.is_empty() {
        debug!(
            "[anti-replay] purged {} expired nonce(s)",
            removed_keys.len()
        );
    }
}

fn now_epoch_secs() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0)
}

fn now_epoch_millis() -> i64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis() as i64)
        .unwrap_or(0)
}

/// Atomically checks-and-marks a (uid, nonce) pair as consumed. Returns
/// `false` if it was already consumed (a replay), `true` if this call
/// is the one that consumed it. Uses `DashMap::entry` for the
/// check-and-insert to be atomic under concurrent requests — the same
/// pattern `token::csrf::CsrfNonceStore::try_consume` uses.
fn try_consume_nonce(uid: &str, nonce: &str, expiry_epoch_secs: u64) -> bool {
    let key = format!("{uid}:{nonce}");
    let inserted = match NONCE_STORE.entry(key.clone()) {
        Entry::Occupied(_) => false,
        Entry::Vacant(v) => {
            v.insert(expiry_epoch_secs);
            true
        }
    };
    if inserted {
        lmdb_put_nonce(&key, expiry_epoch_secs);
    }
    inserted
}

// ─────────────────────────────────────────────────────────────────────────
// HMAC-SHA256, implemented directly on `sha2::Sha256` (already a
// dependency elsewhere in this codebase — see `token::crypto`) rather
// than pulling in a separate `hmac` crate for one function. Standard
// construction, RFC 2104.
// ─────────────────────────────────────────────────────────────────────────

fn hmac_sha256(key: &[u8], message: &[u8]) -> [u8; 32] {
    const BLOCK_SIZE: usize = 64;

    let mut key_block = [0u8; BLOCK_SIZE];
    if key.len() > BLOCK_SIZE {
        let hashed = Sha256::digest(key);
        key_block[..32].copy_from_slice(&hashed);
    } else {
        key_block[..key.len()].copy_from_slice(key);
    }

    let mut ipad = [0x36u8; BLOCK_SIZE];
    let mut opad = [0x5cu8; BLOCK_SIZE];
    for i in 0..BLOCK_SIZE {
        ipad[i] ^= key_block[i];
        opad[i] ^= key_block[i];
    }

    let mut inner = Sha256::new();
    inner.update(ipad);
    inner.update(message);
    let inner_hash = inner.finalize();

    let mut outer = Sha256::new();
    outer.update(opad);
    outer.update(inner_hash);

    let mut out = [0u8; 32];
    out.copy_from_slice(&outer.finalize());
    out
}

// ─────────────────────────────────────────────────────────────────────────
// Canonical string + verification
// ─────────────────────────────────────────────────────────────────────────

/// Everything needed to reconstruct the exact canonical string a
/// signing client builds — see the module doc comment for its shape.
/// `query` must include its leading `?` when non-empty (or be `""`),
/// matching `URL.search` on the client — see `validate_request`, which
/// builds this from an actix `HttpRequest` the same way.
pub struct RequestContext<'a> {
    pub method: &'a str,
    pub scheme: &'a str,
    pub host: &'a str,
    pub port: u16,
    pub path: &'a str,
    pub query: &'a str,
    /// Value of the `X-User` header — a ProxyAuth **username** (see the
    /// module doc comment), looked up directly in `KEY_REGISTRY`.
    pub uid: &'a str,
    pub timestamp: &'a str,
    pub nonce: &'a str,
    pub signature_b64: &'a str,
    pub body: &'a [u8],
}

/// Verifies a single request's signature and records its nonce as
/// consumed. This is the transport-agnostic core — see
/// `validate_request` for the actix-web-facing wrapper `network::proxy`
/// actually calls.
pub fn verify_and_record(ctx: &RequestContext, window_secs: u64) -> Result<(), AntiReplayError> {
    if ctx.uid.is_empty()
        || ctx.timestamp.is_empty()
        || ctx.nonce.is_empty()
        || ctx.signature_b64.is_empty()
    {
        return Err(AntiReplayError::MissingOrMalformedHeaders);
    }

    let secret = match KEY_REGISTRY.get(ctx.uid) {
        Some(s) => s.clone(),
        None => return Err(AntiReplayError::UnknownClient),
    };

    let ts_ms: i64 = match ctx.timestamp.parse() {
        Ok(v) => v,
        Err(_) => return Err(AntiReplayError::MissingOrMalformedHeaders),
    };
    let window_ms = (window_secs as i64).saturating_mul(1000);
    if (now_epoch_millis() - ts_ms).abs() > window_ms {
        return Err(AntiReplayError::ClockSkew);
    }

    let body_hash_b64 = if ctx.body.is_empty() {
        String::new()
    } else {
        B64.encode(Sha256::digest(ctx.body))
    };

    let port_str = ctx.port.to_string();
    let canonical = [
        ctx.method,
        ctx.scheme,
        ctx.host,
        port_str.as_str(),
        ctx.path,
        ctx.query,
        ctx.timestamp,
        ctx.nonce,
        ctx.uid,
        body_hash_b64.as_str(),
    ]
    .join("|");

    let expected = hmac_sha256(secret.as_bytes(), canonical.as_bytes());

    let provided = match B64.decode(ctx.signature_b64) {
        Ok(v) => v,
        Err(_) => return Err(AntiReplayError::MissingOrMalformedHeaders),
    };
    if provided.len() != expected.len() || !bool::from(expected[..].ct_eq(&provided[..])) {
        return Err(AntiReplayError::InvalidSignature);
    }

    // Only reached once the signature is known-valid: a forged/guessed
    // nonce can't be used to burn a victim's real nonce ahead of time.
    let expiry = now_epoch_secs().saturating_add(window_secs);
    if !try_consume_nonce(ctx.uid, ctx.nonce, expiry) {
        return Err(AntiReplayError::Replayed);
    }

    Ok(())
}

/// Splits a `Host` header value into `(host, port)`, lowercased,
/// falling back to `default_port` when no `:port` suffix is present.
/// Handles bracketed IPv6 literals (`[::1]:8080`); a bare `[::1]` with
/// no explicit port also falls back to `default_port`.
fn split_host_port(host_header: &str, default_port: u16) -> (String, u16) {
    let h = host_header.trim();

    if let Some(rest) = h.strip_prefix('[') {
        if let Some(end) = rest.find(']') {
            let host = rest[..end].to_lowercase();
            let after = &rest[end + 1..];
            let port = after
                .strip_prefix(':')
                .and_then(|p| p.parse::<u16>().ok())
                .unwrap_or(default_port);
            return (host, port);
        }
    }

    match h.rsplit_once(':') {
        Some((host, port_str)) => match port_str.parse::<u16>() {
            Ok(p) => (host.to_lowercase(), p),
            Err(_) => (h.to_lowercase(), default_port),
        },
        None => (h.to_lowercase(), default_port),
    }
}

/// The actix-web-facing entry point `network::proxy` calls. `is_secure`
/// should be whatever that call site already uses to decide the
/// externally-visible scheme (see `is_secure_request` in
/// `network::proxy`) — trusting `X-Forwarded-*` only from a configured
/// trusted peer, exactly like the rest of the request handling already
/// does, rather than re-deriving that trust decision here.
pub fn validate_request(
    req: &HttpRequest,
    body: &Bytes,
    is_secure: bool,
    window_secs: u64,
) -> Result<(), AntiReplayError> {
    let get_header = |name: &str| -> String {
        req.headers()
            .get(name)
            .and_then(|v| v.to_str().ok())
            .unwrap_or("")
            .to_string()
    };

    let uid = get_header("x-user");
    let timestamp = get_header("x-timestamp");
    let nonce = get_header("x-nonce");
    let signature = get_header("x-signature");

    let Some(host_header) = req.headers().get(HOST).and_then(|v| v.to_str().ok()) else {
        return Err(AntiReplayError::MissingOrMalformedHeaders);
    };

    let method = req.method().as_str().to_uppercase();
    let scheme = if is_secure { "https" } else { "http" };
    let default_port = if is_secure { 443 } else { 80 };
    let (host, port) = split_host_port(host_header, default_port);

    let path = req.uri().path();
    let query = match req.uri().query() {
        Some(q) if !q.is_empty() => format!("?{q}"),
        _ => String::new(),
    };

    let ctx = RequestContext {
        method: &method,
        scheme,
        host: &host,
        port,
        path,
        query: &query,
        uid: &uid,
        timestamp: &timestamp,
        nonce: &nonce,
        signature_b64: &signature,
        body: body.as_ref(),
    };

    verify_and_record(&ctx, window_secs)
}
