use lettre::{
    AsyncSmtpTransport, AsyncTransport, Message, Tokio1Executor, message::header::ContentType,
    transport::smtp::authentication::Credentials,
};
use serde::{Deserialize, Serialize};
use std::fs;
use std::time::Duration;

pub const RESET_TEMPLATE_PATH: &str = "/etc/proxyauth/mail/templates/reset_password.txt";
pub const ANTI_REPLAY_TEMPLATE_PATH: &str = "/etc/proxyauth/mail/templates/anti_replay_secret.txt";

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct SmtpConfig {
    pub host: String,
    pub port: u16,
    pub username: String,
    pub password: String,
    pub from: String,
    pub timeout_secs: u64,
}

pub struct ResetTemplate {
    pub subject: String,
    pub body: String,
}

/// Same shape as `ResetTemplate` — kept as a separate type rather than
/// reused, since the two templates carry different placeholders
/// (`{{ reset_link }}` vs `{{ secret_anti_replay }}`) and a shared
/// type would invite mixing them up at a call site.
pub struct AntiReplayTemplate {
    pub subject: String,
    pub body: String,
}

pub struct SmtpClient {
    mailer: AsyncSmtpTransport<Tokio1Executor>,
    from: String,
    reset_template: ResetTemplate,
    anti_replay_template: AntiReplayTemplate,
}

impl SmtpClient {
    pub fn new(cfg: &SmtpConfig) -> Result<Self, Box<dyn std::error::Error>> {
        let creds = Credentials::new(cfg.username.clone(), cfg.password.clone());

        let builder = if cfg.port == 465 {
            AsyncSmtpTransport::<Tokio1Executor>::relay(&cfg.host)?.port(cfg.port)
        } else {
            AsyncSmtpTransport::<Tokio1Executor>::starttls_relay(&cfg.host)?.port(cfg.port)
        };

        let mailer = builder
            .credentials(creds)
            .timeout(Some(Duration::from_secs(cfg.timeout_secs)))
            .build();

        // Load + parse reset template
        let raw = fs::read_to_string(RESET_TEMPLATE_PATH).map_err(|e| {
            format!(
                "Failed to read reset password template at {}: {}",
                RESET_TEMPLATE_PATH, e
            )
        })?;
        let reset_template =
            Self::parse_template(&raw).map(|(subject, body)| ResetTemplate { subject, body })?;

        // Load + parse anti-replay secret template
        let raw_ar = fs::read_to_string(ANTI_REPLAY_TEMPLATE_PATH).map_err(|e| {
            format!(
                "Failed to read anti-replay secret template at {}: {}",
                ANTI_REPLAY_TEMPLATE_PATH, e
            )
        })?;
        let anti_replay_template = Self::parse_template(&raw_ar)
            .map(|(subject, body)| AntiReplayTemplate { subject, body })?;

        Ok(Self {
            mailer,
            from: cfg.from.clone(),
            reset_template,
            anti_replay_template,
        })
    }

    /// Parse a `Subject = "..."` first line followed by the body — the
    /// shared shape both `reset_password.txt` and
    /// `anti_replay_secret.txt` follow. Returns `(subject, body)`
    /// rather than either template struct directly, since Rust doesn't
    /// let a single parser return two different named-field types.
    fn parse_template(raw: &str) -> Result<(String, String), Box<dyn std::error::Error>> {
        let mut lines = raw.lines();

        let first_line = lines.next().ok_or("Template is empty")?;

        let subject = if let Some(rest) = first_line.strip_prefix("Subject = ") {
            let trimmed = rest.trim();

            if trimmed.starts_with('"') && trimmed.ends_with('"') {
                trimmed.trim_matches('"').to_string()
            } else {
                return Err("Subject line must be enclosed in double quotes".into());
            }
        } else {
            return Err("First line of template must start with: Subject = \"...\"".into());
        };

        let body = lines.collect::<Vec<_>>().join("\n");

        Ok((subject, body))
    }

    async fn send_text(
        &self,
        to: &str,
        subject: &str,
        body: &str,
    ) -> Result<(), Box<dyn std::error::Error>> {
        let email = Message::builder()
            .from(
                self.from
                    .parse()
                    .map_err(|e| format!("Invalid From address: {}", e))?,
            )
            .to(to
                .parse()
                .map_err(|e| format!("Invalid To address '{}': {}", to, e))?)
            .subject(subject)
            .header(ContentType::TEXT_PLAIN)
            .body(body.to_string())?;

        self.mailer
            .send(email)
            .await
            .map(|_response| ())
            .map_err(|e| format!("Failed to send email via SMTP: {}", e).into())
    }

    fn render_reset_body(&self, username: &str, reset_link: &str) -> String {
        self.reset_template
            .body
            .replace("{{ username }}", username)
            .replace("{{ reset_link }}", reset_link)
    }

    pub async fn send_reset_password(
        &self,
        to: &str,
        username: &str,
        reset_link: &str,
    ) -> Result<(), Box<dyn std::error::Error>> {
        let body = self.render_reset_body(username, reset_link);

        self.send_text(to, &self.reset_template.subject, &body)
            .await
    }

    fn render_anti_replay_body(&self, username: &str, secret_anti_replay: &str) -> String {
        self.anti_replay_template
            .body
            .replace("{{ username }}", username)
            .replace("{{ secret_anti_replay }}", secret_anti_replay)
    }

    /// Sends the one-time anti-replay signing secret email — see
    /// `token::anti_replay`. `secret_anti_replay` is the plaintext
    /// secret; it exists only transiently in memory up to this call and
    /// is never logged or persisted anywhere past it.
    pub async fn send_anti_replay_secret(
        &self,
        to: &str,
        username: &str,
        secret_anti_replay: &str,
    ) -> Result<(), Box<dyn std::error::Error>> {
        let body = self.render_anti_replay_body(username, secret_anti_replay);

        self.send_text(to, &self.anti_replay_template.subject, &body)
            .await
    }
}
