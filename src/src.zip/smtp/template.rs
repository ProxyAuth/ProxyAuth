use crate::smtp::smtp::{ANTI_REPLAY_TEMPLATE_PATH, RESET_TEMPLATE_PATH};
use std::fs;
use std::io::Write;
use std::path::Path;

/// Creates `/etc/proxyauth/mail/templates/reset_password.txt` (and the
/// `templates/` directory, if missing) with a sane default, but only
/// if it doesn't already exist — never overwrites a template an
/// operator has customized. One file per email purpose lives under
/// this directory (`{{ ... }}` placeholders are substituted at send
/// time); `reset_password.txt` and `anti_replay_secret.txt` are the
/// two ProxyAuth currently sends, and the directory is organized to
/// hold more as new email flows are added, without every template
/// competing for the same flat `mail/` folder.
pub fn ensure_reset_template_exists() -> std::io::Result<()> {
    let path = Path::new(RESET_TEMPLATE_PATH);

    if !path.exists() {
        if let Some(parent) = path.parent() {
            fs::create_dir_all(parent)?;
        }

        // Explicit "\n"-joined lines, not an indented raw string block —
        // a raw string literal indented to match the surrounding Rust
        // code would embed that same indentation into every line of
        // the actual email body sent to users.
        let default_template = concat!(
            "Subject = \"ProxyAuth Password Reset\"\n",
            "Hello {{ username }},\n",
            "\n",
            "A password reset request has been initiated for your account.\n",
            "\n",
            "Click the link below to set a new password:\n",
            "{{ reset_link }}\n",
            "\n",
            "This link is valid for a limited time.\n",
            "\n",
            "If you did not request this, simply ignore this message — your\n",
            "current password will keep working.\n",
            "\n",
            "—\n",
            "ProxyAuth Security System\n",
        );

        let mut file = fs::File::create(path)?;
        file.write_all(default_template.as_bytes())?;
        println!("Reset password template created at {}", RESET_TEMPLATE_PATH);
    }

    Ok(())
}

/// Same idea as `ensure_reset_template_exists`, for the anti-replay
/// signing-plugin welcome email — created (once, never overwritten)
/// the first time `plugin_anti_replay: true` needs to send one; see
/// `token::anti_replay`. Contains `{{ username }}` and `{{
/// secret_anti_replay }}` placeholders — the latter is the raw
/// plaintext secret the recipient pastes into the signing extension's
/// "domaine + clé secrète" form.
pub fn ensure_anti_replay_secret_template_exists() -> std::io::Result<()> {
    let path = Path::new(ANTI_REPLAY_TEMPLATE_PATH);

    if !path.exists() {
        if let Some(parent) = path.parent() {
            fs::create_dir_all(parent)?;
        }

        let default_template = concat!(
            "Subject = \"Your ProxyAuth request-signing secret\"\n",
            "Hello {{ username }},\n",
            "\n",
            "Request signing has been enabled on your ProxyAuth account.\n",
            "Below is your personal signing secret — enter it in the ProxyAuth\n",
            "browser extension, alongside your username, to start signing your\n",
            "requests to protected domains:\n",
            "\n",
            "{{ secret_anti_replay }}\n",
            "\n",
            "This secret is shown only once and cannot be recovered later — if\n",
            "you lose it, ask an administrator to reset it, which will trigger a\n",
            "new one to be generated and emailed to you.\n",
            "\n",
            "Keep it as confidential as a password: anyone with this secret can\n",
            "sign requests as you.\n",
            "\n",
            "If you did not expect this email, contact your administrator.\n",
            "\n",
            "—\n",
            "ProxyAuth Security System\n",
        );

        let mut file = fs::File::create(path)?;
        file.write_all(default_template.as_bytes())?;
        println!(
            "Anti-replay secret template created at {}",
            ANTI_REPLAY_TEMPLATE_PATH
        );
    }

    Ok(())
}
